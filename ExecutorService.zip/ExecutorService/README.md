#

## Keeping a recent executionId cache
### Caffeine In-Memory Cache ( 2 min TTL)
I used Caffeine instead of ConcurrentHashMap because:
1. Automatic expiration
2. Maximum size limit
3. Highly optimized
4. Thread-safe
5. No cleanup thread required.
Caffeine performs `lazy eviction`.That means expired entries are removed:
* during writes
* during reads
* during periodic maintenance
So an expired entry may remain in memory for a short time until maintenance runs. However, cache.getIfPresent(E1) -> null after expiry<br>
* Caffeine stores expiration information alongside entries, and it doesn't periodically walk the entire map.
* Cleanup simply checks the oldest entry from Doubly Linked list and remove it if it expired(Saves us from scanning all entries).

Still can lead to duplicate execution if:
1. Both Scheduler and Executor crash within 2-minute window.
2. Executor crash without commiting offset -->leads to Kafka re-delivering event.
So it's a best-effort duplicate suppression, not `exactly-once` processing.

## Kafka Consumer configurations
### max-poll-records: 
1. Consumer poll() Kafka Broker when it needed messages to process.And max-poll-records represents how much messages in one poll()
 it can take from Broker.
2. If `max-poll-records`=1 ===> So for each event Consumer needs to make n/w call to Broker. So why doesn't everyone use a huge value ?
because If processing of those large number of records takes too long (longer than `max.poll.interval.ms`, default 5 minutes), Kafka assumes the consumer is dead and triggers a rebalance.
3. Hence i will use default value 500. 
4. And Sping internally set poll duration to 5 second(default) (Duration.ofSeconds(5)) -- which means Consumer will wait for 5 sec if Broker does not have new messages.

### enable-auto-commit: 
if it is `true`
1. Kafka commits offsets periodically (default every 5 seconds).It has nothing to do whether consumer crashed after commit but before processing.
2. And now Kafka thinks it is processed.<br>
If it is `false` we will use manual commit.---> ack.acknowledge() after everything finishes for that record.<br>
Hence we will use `kafka.listener.ack-mode= manual_immediate`.

### kafka.listener.concurrency
1. Kafka create 1 consumer thread for all the partition of topic it will consume from p1 → then from p2 → then from p3.
2. concurrency =4  ===> four consumer threads consuming. Each thread acts like an independent Kafka consumer in the same consumer group.
3. 2 Executor-service instance with concurrency = 2 ===> 4 consumers. Kafka distributes 6 partitions among these 4 consumers.

### DefaultErrorHandler
It is used before the message leaves the original topic.<br>
These retries are intended for very short-lived transient problems, such as:<br>
1. Temporary broker hiccup
2. Brief database connection interruption
3. Momentary network glitch

The retries happen in the same consumer thread and can block it while waiting.<br>
Retry topics become the durable, observable workflow for job retries, while DefaultErrorHandler remains responsible only for Kafka consumer infrastructure concerns.<br>
