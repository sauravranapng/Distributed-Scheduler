#

## Keeping a recent executionId cache
### Caffeine In-Memory Cache ( 2 min TTL)
I used Caffeine instead of ConcurrentHashMap because:
1. Automatic expiration
2. Maximum size limit
3. Highly optimized
4. Thread-safe
5. No cleanup thread required.
Caffeine performs `lazy eviction`.That means expired entries are removed:
* during writes
* during reads
* during periodic maintenance
So an expired entry may remain in memory for a short time until maintenance runs. However, cache.getIfPresent(E1) -> null after expiry<br>
* Caffeine stores expiration information alongside entries, and it doesn't periodically walk the entire map.
* Cleanup simply checks the oldest entry from Doubly Linked list and remove it if it expired(Saves us from scanning all entries).

Still can lead to duplicate execution if:
1. Both Scheduler and Executor crash within 2-minute window.
2. Executor crash without commiting offset -->leads to Kafka re-delivering event.
So it's a best-effort duplicate suppression, not `exactly-once` processing.

