package com.saurav.executorservice.executor.impl;

import com.saurav.executorservice.exception.PayloadDeserializationException;
import com.saurav.executorservice.model.enums.JobType;
import com.saurav.executorservice.model.event.JobExecutionEvent;
import com.saurav.executorservice.model.payload.HttpJobPayload;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClient;
import tools.jackson.databind.ObjectMapper;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class HttpJobExecutorTest {

    private ObjectMapper objectMapper;

    private HttpJobExecutor httpJobExecutor;

    @BeforeEach
    void setUp() {

        objectMapper = mock(ObjectMapper.class);
        RestClient restClient = mock(RestClient.class);

        httpJobExecutor =
                new HttpJobExecutor(
                        objectMapper,
                        restClient);

        ReflectionTestUtils.setField(
                httpJobExecutor,
                "testDelayMs",
                0L);
    }

    @Test
    void supportedType_shouldReturnHttp() {

        assertEquals(
                JobType.HTTP,
                httpJobExecutor.supportedType());
    }

    @Test
    void execute_shouldThrowPayloadDeserializationExceptionForInvalidPayload()
            throws Exception {

        JobExecutionEvent event =
                buildEvent(
                        "invalid-json");

        RuntimeException parsingException =
                new RuntimeException("Invalid JSON");

        when(objectMapper.readValue(
                event.getJobPayload(),
                HttpJobPayload.class))
                .thenThrow(parsingException);

        PayloadDeserializationException exception =
                assertThrows(
                        PayloadDeserializationException.class,
                        () -> httpJobExecutor.execute(event));

        assertEquals(
                "Failed to deserialize HTTP job payload",
                exception.getMessage());

        assertEquals(
                parsingException,
                exception.getCause());
    }

    @Test
    void execute_shouldDeserializeValidPayload() throws Exception {

        JobExecutionEvent event =
                buildEvent(
                        """
                        {
                          "method": "GET",
                          "url": "http://example.com"
                        }
                        """);

        HttpJobPayload payload =
                new HttpJobPayload();

        payload.setMethod("GET");
        payload.setUrl("http://example.com");

        when(objectMapper.readValue(
                event.getJobPayload(),
                HttpJobPayload.class))
                .thenReturn(payload);

        /*
         * The fluent RestClient chain is not fully mocked here.
         * This test mainly verifies that valid payload deserialization
         * succeeds.
         */
        assertThrows(
                Exception.class,
                () -> httpJobExecutor.execute(event));
    }

    private JobExecutionEvent buildEvent(String payload) {

        return JobExecutionEvent.builder()
                .executionId(UUID.randomUUID())
                .userId(UUID.randomUUID())
                .jobId(UUID.randomUUID())
                .scheduledExecutionTime(Instant.now())
                .jobType(JobType.HTTP)
                .jobPayload(payload)
                .build();
    }
}